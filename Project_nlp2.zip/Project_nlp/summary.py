import os
import pdfplumber
from docx import Document
from flask import Flask, request, render_template, g, jsonify
import mysql.connector
import json
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from transformers import T5Tokenizer, AutoModelForSeq2SeqLM

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ✅ MySQL Connection
def get_db():
    if 'db' not in g:
        g.db = mysql.connector.connect(
            host="127.0.0.1",  # Use 127.0.0.1 instead of localhost
            user="root",        # MySQL username
            password="",        # MySQL password (if any)
            database="project_nlp",  # Make sure this matches the database name
            pool_name="mypool",
            pool_size=5
        )
    return g.db

# --- ✅ โหลดโมเดล ---
search_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
summary_tokenizer = T5Tokenizer.from_pretrained("csebuetnlp/mT5_multilingual_XLSum")
summary_model = AutoModelForSeq2SeqLM.from_pretrained("csebuetnlp/mT5_multilingual_XLSum")

# --- 📥 ฟังก์ชันโหลดไฟล์ ---
def load_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def load_pdf(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text

def load_docx(file_path):
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

# --- 📂 โหลดเอกสารทั้งหมด ---
def load_documents(folder):
    docs, filenames = [], []
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        if filename.endswith('.txt'):
            content = load_txt(file_path)
        elif filename.endswith('.pdf'):
            content = load_pdf(file_path)
        elif filename.endswith('.docx'):
            content = load_docx(file_path)
        else:
            continue
        docs.append(content)
        filenames.append(filename)
    return docs, filenames

# --- 📝 ฟังก์ชันสรุปข้อความ ---
def summarize_text(text, max_length=150, min_length=50):
    # ลบช่องว่างและการขึ้นบรรทัดใหม่ที่ไม่จำเป็น
    text = text.replace("\n", " ").strip()

    # คำสั่งในการให้โมเดลทำการสรุป
    inputs = summary_tokenizer("summarize: " + text, return_tensors="pt", truncation=True, max_length=512)

    # สร้างข้อความสรุป
    summary_ids = summary_model.generate(inputs["input_ids"], 
                                         max_length=max_length, 
                                         min_length=min_length, 
                                         num_beams=5,    # เพิ่ม num_beams เพื่อเพิ่มความแม่นยำ
                                         early_stopping=True)

    # แปลงข้อความที่ได้จากโมเดลกลับเป็นข้อความที่อ่านได้
    summary = summary_tokenizer.decode(summary_ids[0], skip_special_tokens=True)

    # หากมีข้อความสรุปที่ยาวเกินไป ให้นำมาปรับขนาดให้เหมาะสม
    if len(summary) > max_length:
        summary = summary[:max_length]

    # กำจัดช่องว่างที่ไม่จำเป็น
    summary = ' '.join(summary.split())

    return summary

# --- 🔍 ค้นหาเอกสาร ---
def search_documents(query, docs, filenames):
    query_emb = search_model.encode([query], convert_to_numpy=True)
    doc_embs = search_model.encode(docs, convert_to_numpy=True)
    similarities = cosine_similarity(query_emb, doc_embs)[0]
    ranked_indices = np.argsort(similarities)[::-1]
    return [(filenames[i], docs[i], similarities[i]) for i in ranked_indices]

# --- 🚀 Web App ---
@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    if request.method == 'POST':
        query = request.form['query']
        docs, filenames = load_documents('uploads')  # 📂 โฟลเดอร์เก็บไฟล์
        ranked_results = search_documents(query, docs, filenames)
        for filename, doc, score in ranked_results[:5]:  # แสดง 5 ไฟล์แรก
            summary = summarize_text(doc)
            results.append({'filename': filename, 'score': round(score, 2), 'summary': summary})
    return render_template('summary.html', results=results)

@app.route("/search", methods=["GET", "POST"])
def search():
    results = []
    if request.method == "POST":
        search_term = request.form["search"]
        db = get_db()
        cursor = db.cursor(dictionary=True)
        
        # Query the database for items matching the search term in the 'filename' column of the 'documents' table
        query = "SELECT * FROM documents WHERE filename LIKE %s"
        cursor.execute(query, ('%' + search_term + '%',))
        results = cursor.fetchall()
        cursor.close()

    return render_template("search_results.html", results=results)

@app.route("/upload", methods=["POST"])
def upload_file():
    """Handles document uploads and stores embeddings in MySQL."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    # Extract text
    if file.filename.endswith(".pdf"):
        text = load_pdf(file_path)
    elif file.filename.endswith(".docx"):
        text = load_docx(file_path)
    elif file.filename.endswith(".txt"):
        text = load_txt(file_path)
    else:
        return jsonify({"error": "Unsupported file type"}), 400

    # Encode and store embeddings
    embedding = search_model.encode(text).tolist()
    embedding_json = json.dumps(embedding)

    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO documents (filename, content, embedding) VALUES (%s, %s, %s)",
        (file.filename, text, embedding_json)
    )
    db.commit()

    return jsonify({"message": "File uploaded and processed successfully"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5500)
